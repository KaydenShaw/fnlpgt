import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.Random;

public class ExpandingSnake extends JFrame {
    public ExpandingSnake() {
        setTitle("Expanding Snake - Press 'C' to Customize Background");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        GamePanel panel = new GamePanel(this);
        add(panel);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(ExpandingSnake::new);
    }
}

class GamePanel extends JPanel implements ActionListener {
    private final JFrame frame;
    private final int UNIT_SIZE = 25;
    private final int INITIAL_GRID_SIZE = 15;
    private int gridWidth = INITIAL_GRID_SIZE;
    private int gridHeight = INITIAL_GRID_SIZE;
    private final int MAX_GRID_SIZE = 30;
    
    private Color bgColor = Color.BLACK;
    private Image bgImage = null;
    private boolean useImage = false;
    
    private final ArrayList<Point> snake = new ArrayList<>();
    private Point food;
    private char direction = 'R';
    private boolean running = false;
    
    private final Timer gameTimer;
    private final Timer expansionTimer;
    private final Random random;

    private final int EXPANSION_DELAY = 30 * 1000;
    private long expansionTargetTime;
    private long pausedRemainingTime = 0;

    public GamePanel(JFrame frame) {
        this.frame = frame;
        int maxScreenSize = MAX_GRID_SIZE * UNIT_SIZE;
        setPreferredSize(new Dimension(maxScreenSize, maxScreenSize));
        setBackground(bgColor);
        setFocusable(true);
        addKeyListener(new KeyHandler());
        random = new Random();
        
        gameTimer = new Timer(100, this);
        expansionTimer = new Timer(EXPANSION_DELAY, e -> expandBorders());
        startGame();
    }

    public void loadBackgroundImage(String path) {
        File file = new File(path);
        if (file.exists()) {
            bgImage = new ImageIcon(path).getImage();
            useImage = true;
        }
    }

    private void startGame() {
        snake.clear();
        gridWidth = INITIAL_GRID_SIZE;
        gridHeight = INITIAL_GRID_SIZE;
        
        int offset = ((MAX_GRID_SIZE - gridWidth) / 2) * UNIT_SIZE;
        int startX = offset + (gridWidth / 2) * UNIT_SIZE;
        int startY = offset + (gridHeight / 2) * UNIT_SIZE;
        
        snake.add(new Point(startX, startY));
        direction = 'R';
        
        spawnFood();
        running = true;
        expansionTargetTime = System.currentTimeMillis() + EXPANSION_DELAY;
        
        gameTimer.start();
        expansionTimer.setInitialDelay(EXPANSION_DELAY);
        expansionTimer.start();
    }

    private void spawnFood() {
        int offset = ((MAX_GRID_SIZE - gridWidth) / 2) * UNIT_SIZE;
        boolean invalidLocation;
        int x, y;
        
        do {
            invalidLocation = false;
            x = offset + random.nextInt(gridWidth) * UNIT_SIZE;
            y = offset + random.nextInt(gridHeight) * UNIT_SIZE;
            
            for (Point cell : snake) {
                if (cell.x == x && cell.y == y) {
                    invalidLocation = true;
                    break;
                }
            }
        } while (invalidLocation);
        
        food = new Point(x, y);
    }

    private void expandBorders() {
        if (gridWidth < MAX_GRID_SIZE) {
            gridWidth += 2;
            gridHeight += 2;
            expansionTargetTime = System.currentTimeMillis() + EXPANSION_DELAY;
            
            expansionTimer.setInitialDelay(EXPANSION_DELAY);
            expansionTimer.restart();
            repaint();
        } else {
            expansionTimer.stop();
        }
    }

    private void openColorChooser() {
        boolean wasRunning = running;
        if (wasRunning) {
            gameTimer.stop();
            expansionTimer.stop();
            pausedRemainingTime = expansionTargetTime - System.currentTimeMillis();
        }

        Color chosenColor = JColorChooser.showDialog(frame, "Choose Background Color", bgColor);
        if (chosenColor != null) {
            bgColor = chosenColor;
            useImage = false;
            setBackground(bgColor);
        }

        if (wasRunning) {
            expansionTargetTime = System.currentTimeMillis() + pausedRemainingTime;
            gameTimer.start();
            if (gridWidth < MAX_GRID_SIZE) {
                expansionTimer.setInitialDelay((int) Math.max(0, pausedRemainingTime));
                expansionTimer.restart();
            }
        }
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (useImage && bgImage != null) {
            g.drawImage(bgImage, 0, 0, getWidth(), getHeight(), this);
        } else {
            g.setColor(bgColor);
            g.fillRect(0, 0, getWidth(), getHeight());
        }
        if (running) {
            drawGame(g);
        } else {
            gameOver(g);
        }
    }

    private void drawGame(Graphics g) {
        int offset = ((MAX_GRID_SIZE - gridWidth) / 2) * UNIT_SIZE;
        int displayWidth = gridWidth * UNIT_SIZE;
        int displayHeight = gridHeight * UNIT_SIZE;

        g.setColor(new Color(0, 0, 0, 150));
        g.fillRect(0, 0, getWidth(), offset);
        g.fillRect(0, offset + displayHeight, getWidth(), getHeight());
        g.fillRect(0, offset, offset, displayHeight);
        g.fillRect(offset + displayWidth, offset, getWidth(), displayHeight);

        g.setColor(Color.LIGHT_GRAY);
        g.drawRect(offset, offset, displayWidth, displayHeight);

        g.setColor(Color.RED);
        g.fillOval(food.x, food.y, UNIT_SIZE, UNIT_SIZE);

        for (int i = 0; i < snake.size(); i++) {
            g.setColor(i == 0 ? Color.GREEN : new Color(45, 180, 0));
            g.fillRect(snake.get(i).x, snake.get(i).y, UNIT_SIZE, UNIT_SIZE);
        }

        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.PLAIN, 12));
        g.drawString("Press 'C' to change background", 10, 20);

        String timerString;
        if (gridWidth >= MAX_GRID_SIZE) {
            timerString = "Grid: MAX SIZE";
        } else {
            long timeLeft = Math.max(0, expansionTargetTime - System.currentTimeMillis());
            long minutes = (timeLeft / 1000) / 60;
            long seconds = (timeLeft / 1000) % 60;
            timerString = String.format("Next Expansion: %02d:%02d", minutes, seconds);
        }
        g.drawString(timerString, getWidth() - 150, 20);
    }

    private void move() {
        Point head = snake.get(0);
        Point newHead = new Point(head.x, head.y);

        switch (direction) {
            case 'U' -> newHead.y -= UNIT_SIZE;
            case 'D' -> newHead.y += UNIT_SIZE;
            case 'L' -> newHead.x -= UNIT_SIZE;
            case 'R' -> newHead.x += UNIT_SIZE;
        }
        
        snake.add(0, newHead);

        if (newHead.x == food.x && newHead.y == food.y) {
            spawnFood();
        } else {
            snake.remove(snake.size() - 1);
        }
    }

    private void checkCollision() {
        Point head = snake.get(0);
        int offset = ((MAX_GRID_SIZE - gridWidth) / 2) * UNIT_SIZE;
        int maxBound = offset + (gridWidth * UNIT_SIZE);

        if (head.x < offset || head.x >= maxBound || head.y < offset || head.y >= maxBound) {
            running = false;
        }

        for (int i = 1; i < snake.size(); i++) {
            if (head.x == snake.get(i).x && head.y == snake.get(i).y) {
                running = false;
                break;
            }
        }

        if (!running) {
            gameTimer.stop();
            expansionTimer.stop();
        }
    }

    private void gameOver(Graphics g) {
        String msg = "Game Over - Score: " + (snake.size() - 1);
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 20));
        FontMetrics metrics = getFontMetrics(g.getFont());
        g.drawString(msg, (getWidth() - metrics.stringWidth(msg)) / 2, getHeight() / 2);

        g.setFont(new Font("Arial", Font.BOLD, 14));
        String restartMsg = "Press SPACE to Restart | Press C to Customize Background";
        g.drawString(restartMsg, (getWidth() - getFontMetrics(g.getFont()).stringWidth(restartMsg)) / 2, (getHeight() / 2) + 30);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (running) {
            move();
            checkCollision();
            repaint();
        }
    }

    private class KeyHandler extends KeyAdapter {
        @Override
        public void keyPressed(KeyEvent e) {
            int key = e.getKeyCode();

            if (key == KeyEvent.VK_C) {
                openColorChooser();
                return;
            }

            if (running) {
                if ((key == KeyEvent.VK_LEFT || key == KeyEvent.VK_A) && direction != 'R') direction = 'L';
                if ((key == KeyEvent.VK_RIGHT || key == KeyEvent.VK_D) && direction != 'L') direction = 'R';
                if ((key == KeyEvent.VK_UP || key == KeyEvent.VK_W) && direction != 'D') direction = 'U';
                if ((key == KeyEvent.VK_DOWN || key == KeyEvent.VK_S) && direction != 'U') direction = 'D';
            } else {
                if (key == KeyEvent.VK_SPACE) {
                    startGame();
                    repaint();
                }
            }
        }
    }
}